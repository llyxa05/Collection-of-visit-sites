var _____WB$wombat$assign$function_____ = function(name) {return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name)) || self[name]; };
if (!self.__WB_pmw) { self.__WB_pmw = function(obj) { this.__WB_source = obj; return this; } }
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opener = _____WB$wombat$assign$function_____("opener");

		var option_navigation_mode = "sticky";
		var option_animate_content_on_scroll = "on";
		var option_parallax_scrolling = "on";
		var option_hero_animate_content_on_scroll = "on";
		var option_hero_3d_hover_effect = "on";
		var option_hero_parallax_hover_effect = "on";
		var option_hero_gravity_effect = "on";
		var option_hero_background_mode = "youtube";
				var option_hero_background_slider_delay = 6000;
				var option_hero_background_slider_transition = "slideDown";
				var option_hero_background_slider_transitionDuration = 800;
				var option_hero_background_kenburns_delay = 6000;
				var option_hero_background_kenburns_transition = "slideDown";
				var option_hero_background_kenburns_transitionDuration = 800;
				var option_hero_background_youtube_url = "https://web.archive.org/web/20190324213555/https://youtu.be/3hGPeFF5EhY";
				// START POINT IN SECONDS
				var option_hero_background_youtube_startPoint = 0;
				// END POINT IN SECONDS
				var option_hero_background_youtube_endPoint = 19;
				var option_hero_background_youtube_mute = "off"
				var option_hero_background_youtube_loop = "on";
				var option_hero_background_youtube_controls = "on";
				var option_hero_background_youtube_smart_pause = "on"; 
				var option_hero_background_color_custom_color = "#6e00ff";
				var option_hero_background_gradient_colorArray = new Array( [62,35,255], [60,255,60], [255,35,98], [45,175,230], [255,0,255], [255,128,0] );
				var option_hero_background_gradient_stransitionSpeed = 8;
				var option_hero_background_sphere_distance = 300;
				var option_hero_background_sphere_rotation_speed = 0.2;
				var option_hero_background_sphere_line_color = "#ffffff";
				var option_hero_background_sphere_dot_color = "#ffffff";
				var option_hero_background_sphere_background_color = "#000000";
				var option_hero_background_waves_distance = 1500;
				var option_hero_background_waves_dotSpacing = 120;
				var option_hero_background_waves_dotAmountX = 20;
				var option_hero_background_waves_dotAmountY = 60;
				var option_hero_background_waves_dot_color = "#ffffff";
				var option_hero_background_waves_background_color = "#000000";
				var option_hero_background_mesh_color = "#ffffff";
				var option_hero_background_mesh_background_color = "#111111";
				var option_hero_background_mesh_spotlight_size = 600;
				var option_hero_background_space_star_amount = 512;
				var option_hero_background_space_star_speed = 2.5;
				var option_hero_background_star_star_color = "#ffffff";
				var option_hero_background_star_background_color = "#000000";
				var option_hero_background_abstract_bg_color = "#d1c395";
				var option_hero_background_move_speed = 10;
				var option_hero_background_width = 75;
				var option_hero_background_width_expansion = 0.8;
				function customBackground() {
					$("#canvas").css("background","#00AB39");
				}
		var option_analytics_tracking = "off";
		var option_analytics_tracking_id = "UA-XXXXXXXX-X";

}
/*
     FILE ARCHIVED ON 21:35:55 Mar 24, 2019 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 20:04:52 Dec 15, 2021.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  RedisCDXSource: 2.277
  PetaboxLoader3.datanode: 168.671 (4)
  exclusion.robots.policy: 0.202
  PetaboxLoader3.resolve: 68.125
  esindex: 0.014
  exclusion.robots: 0.217
  CDXLines.iter: 22.316 (3)
  LoadShardBlock: 180.81 (3)
  load_resource: 138.092
  captures_list: 209.159
*/